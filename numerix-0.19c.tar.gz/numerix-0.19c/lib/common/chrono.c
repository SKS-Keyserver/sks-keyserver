/* +------------------------------------------------------------------------+
   |                                                                        |
   |                        Chronom�trage des calculs                       |
   |                                                                        |
   +------------------------------------------------------------------------+ */

/* M. Quercia, 31/01/2001 */

#include <stdlib.h>
#include <stdio.h>
#include <sys/times.h>
#include <time.h>


void chrono(char *msg) {
  static double tlast = 0;
  double t;
  struct tms buf;

  times(&buf);
  t = (double)(buf.tms_utime + buf.tms_stime)/CLK_TCK;
  fprintf(stderr,"%8.2f %8.2f %s\n",t,t-tlast,msg);
  fflush(stderr);
  tlast = t;
}

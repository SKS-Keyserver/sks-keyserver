/* +------------------------------------------------------------------------+
   |                                                                        |
   |                      Entiers de longueur arbitraire                    |
   |                                                                        |
   |               Liste des fonctions impl�ment�es en assembleur           |
   |                                                                        |
   +------------------------------------------------------------------------+ */


/* M. Quercia, 08/02/2001 */

#ifdef use_slong

/* addition/soustraction */
#define have_sn_add
#define have_sn_sub
#define have_sn_inc_1
#define have_sn_inc
#define have_sz_addsub
#define have_sn_dec_1
#define have_sn_dec

/* comparaison */
#define have_sn_cmp
#define have_sz_cmp

/* d�calage */
#define	have_sn_shr
#define	have_sn_shl
#define	have_sz_shift

/* multiplication */
#define	have_sn_mul_2
#define	have_sz_mul_2
#define	have_sn_mul_n2
#define	have_sz_mul_n2
#define have_sn_karamul

/* carr� */
#define have_sn_sqr_n2
#define have_sn_karasqr
#define have_sn_sqr_k
#define have_sz_sqr_k

/* division */
#define	have_sn_quo_2
#define	have_sz_quo_2
#define	have_sn_quo_n2
#define have_sn_hquo
#define have_sz_quo_n2

/* FFT modulo base^n+1 */
#define have_sn_sc_add
#define have_sn_sc_sub
#define have_sn_sc_mul
#define have_sn_sc_shift

#endif
